
export interface OperationResultModel {
      error: boolean;
      errorMessage: string;
      result: any;
}

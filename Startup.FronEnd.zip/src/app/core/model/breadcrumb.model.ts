

import {  Params } from '@angular/router';

export interface BreadcrumbModel {
    name: string;
    url: string;
    params?: Params;

}

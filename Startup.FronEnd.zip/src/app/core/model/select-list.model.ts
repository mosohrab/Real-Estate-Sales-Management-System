export interface SelectListModel {
    value: any;
    text: string;
}

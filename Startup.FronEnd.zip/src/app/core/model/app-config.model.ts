

export interface AppConfigModel {
    host: string;
    apiHost: string;

}

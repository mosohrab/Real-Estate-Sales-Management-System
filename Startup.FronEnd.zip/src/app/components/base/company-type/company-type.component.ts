import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-type',
  templateUrl: './company-type.component.html',
  styleUrls: ['./company-type.component.scss']
})
export class CompanyTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

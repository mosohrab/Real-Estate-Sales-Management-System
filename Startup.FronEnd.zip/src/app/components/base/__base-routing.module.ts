// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';


// import { CityComponent } from './city/city.component';
// import { CountryComponent } from './country/country.component';
// import { BuildingStructureTypeComponent } from './building-structure-type/building-structure-type.component';
// import { CompanyTypeComponent } from './company-type/company-type.component';
// import { ProvinceComponent } from './province/province.component';
// import { ScaleComponent } from './scale/scale.component';

// const routes: Routes = [
//    { path: 'country', component: CountryComponent },
//    { path: 'city', component: CityComponent },
//    { path: 'buildingstructuretype', component: BuildingStructureTypeComponent },
//    { path: 'province', component: ProvinceComponent },
//    { path: 'scale', component: ScaleComponent },
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class BaseRoutingModule { }

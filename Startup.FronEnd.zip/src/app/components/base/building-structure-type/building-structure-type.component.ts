import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-structure-type',
  templateUrl: './building-structure-type.component.html',
  styleUrls: ['./building-structure-type.component.scss']
})
export class BuildingStructureTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

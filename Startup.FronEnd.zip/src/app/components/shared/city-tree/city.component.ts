import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-city-tree',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.scss']
})
export class CityTreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

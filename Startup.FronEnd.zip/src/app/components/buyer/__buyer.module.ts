// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { BuyerRoutingModule } from './buyer-routing.module';

// @NgModule({
//   imports: [
//     CommonModule,
//     BuyerRoutingModule
//   ],
//   declarations: []
// })
// export class BuyerModule { }

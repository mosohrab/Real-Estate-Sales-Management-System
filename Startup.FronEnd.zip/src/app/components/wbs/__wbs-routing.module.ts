// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';

// import { WbsComponent } from './wbs/wbs.component';

// const routes: Routes = [
//   { path: 'wbs', component: WbsComponent },
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class WbsRoutingModule { }

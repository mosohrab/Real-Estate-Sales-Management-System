// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { WbsRoutingModule } from './wbs-routing.module';
// import { WbsComponent } from './wbs/wbs.component';

// @NgModule({
//   imports: [
//     CommonModule,
//     WbsRoutingModule
//   ],
//   declarations: [WbsComponent]
// })
// export class WbsModule { }

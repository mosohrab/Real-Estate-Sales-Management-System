// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { UnitRoutingModule } from './unit-routing.module';

// @NgModule({
//   imports: [
//     CommonModule,
//     UnitRoutingModule
//   ],
//   declarations: []
// })
// export class UnitModule { }

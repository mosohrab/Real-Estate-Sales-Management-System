import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-feature-title',
  templateUrl: './feature-title.component.html',
  styleUrls: ['./feature-title.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FeatureTitleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

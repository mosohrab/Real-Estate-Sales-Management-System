import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-measuring-unit',
  templateUrl: './measuring-unit.component.html',
  styleUrls: ['./measuring-unit.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MeasuringUnitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}



// tslint:disable-next-line:no-empty-interface
export interface ProvinceModel {
    provinceId: number;
    provinceName: string;
    countryId: number;
    countryName: string;
}

export interface CityModel {
    cityId: number;
    cityName: string;

    provinceId: number;
    provinceName: string;

    countryId: number;
    countryName: string;

}


export interface CountryModel {
    countryId: number;
    countryName: string;
}


export interface BuildingstructuretypeModel {

    buildingStructureTypeId: number;
    buildingStructureTypeName: string;
}


export interface ScaleModel {
    scaleId: number;
    scaleName: string;
    scaleType: string;
}


